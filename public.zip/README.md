# 🚀 AetherMail — Self-Hosted Email Server & Multi-Tenant SaaS Platform

A modern, high-performance, self-hosted email server engine and webmail platform built with **Node.js**, **RFC 5321 SMTP Server**, **MIME Mailparser**, and **SQLite Database Persistence**.

---

## ✨ Features (Phase 1 Implemented)

- **Native RFC 5321 SMTP Receiver:**
  - Listens on `0.0.0.0:2525` (configurable to port `25`).
  - Strict Virtual Mailbox Recipient Validation (rejects non-existent users with RFC 550).
  - Client SMTP Authentication (AUTH PLAIN / AUTH LOGIN).
- **MIME & Multipart Parser:**
  - Parses HTML body, plain text, headers, and binary attachments.
- **Embedded Database Storage:**
  - Multi-tenant SQLite database (`node:sqlite`) for domains, mailboxes, messages, attachments, and logs.
  - Zero external DB server requirement.
- **Automated DKIM & DNS Generator:**
  - Generates 2048-bit RSA DKIM private & public keypairs for any connected domain.
  - Generates complete DNS records: MX, SPF (`v=spf1 mx ~all`), DKIM (`v=DKIM1`), and DMARC (`v=DMARC1`).
- **Internal Inter-Domain Routing:**
  - Instant local routing between any mailboxes and domains on the platform without needing external internet DNS.
- **Modern Webmail & SaaS Dashboard:**
  - Sleek Glassmorphic dark-mode UI.
  - Inbox, Sent, Trash with real-time Server-Sent Events (SSE) live updates.
  - Secure sandboxed HTML email reader pane & attachment downloader.
  - Real-time Live SMTP Socket Activity Stream.

---

## 🛠️ Quick Start

### 1. Install Dependencies
Open PowerShell in this folder (`d:\waseem desktop\projects\email-server`):
```powershell
npm install
```

### 2. Start Email Server & Webmail
```powershell
npm start
```
- **Webmail & Dashboard:** Open [http://localhost:3000](http://localhost:3000)
- **SMTP Receiver Server:** Listening on `127.0.0.1:2525`

### 3. Run SMTP Transmission Verification Test
In another terminal, send a real RFC 5321 test email with an attachment:
```powershell
npm run test:smtp
```
Watch the test email instantly appear in your Webmail inbox at [http://localhost:3000](http://localhost:3000)!

---

## 📁 Project Architecture

```
email-server/
├── mailserver.db              # SQLite Database (auto-created on first run)
├── package.json               # Node.js dependencies & scripts
├── test-smtp.js               # RFC 5321 SMTP test transmitter
├── src/
│   ├── server.js              # Express REST API, SSE & Web Server
│   ├── db/
│   │   └── database.js        # SQLite schema, DKIM RSA generator, Mailbox CRUD
│   └── smtp/
│       ├── receiver.js        # smtp-server RFC 5321 receiver & mailparser
│       └── sender.js          # Outbound & local inter-domain routing
└── public/
    ├── index.html             # SaaS Dashboard & Webmail layout
    ├── style.css              # Glassmorphic dark-mode design system
    └── app.js                 # Real-time Webmail client & state
```
