import express from 'express';
import cors from 'cors';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

import {
  db,
  getDomains,
  createDomain,
  getDomainById,
  getMailboxes,
  createMailbox,
  getMailboxById,
  getEmails,
  getEmailById,
  markEmailRead,
  toggleStarEmail,
  deleteEmail,
  getSmtpLogs,
  getStats,
  saveEmail,
  logSmtp
} from './db/database.js';

import { startSmtpReceiver, smtpEvents } from './smtp/receiver.js';
import { sendEmail } from './smtp/sender.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const HOST = process.env.HOST || '127.0.0.1'; // Secure local loopback binding
const WEB_PORT = process.env.PORT || 3000;
const SMTP_PORT = process.env.SMTP_PORT || 2525;

// Strict CORS: Allow only local web app
app.use(
  cors({
    origin: [`http://127.0.0.1:${WEB_PORT}`, `http://localhost:${WEB_PORT}`],
    methods: ['GET', 'POST', 'DELETE']
  })
);

app.use(express.json({ limit: '25mb' }));
app.use(express.static(path.resolve(__dirname, '../public')));

// Server-Sent Events (SSE) for Real-Time UI Updates
const sseClients = new Set();

app.get('/api/events', (req, res) => {
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');
  res.flushHeaders();

  const client = { res };
  sseClients.add(client);

  req.on('close', () => {
    sseClients.delete(client);
  });
});

function broadcast(type, data) {
  for (const client of sseClients) {
    try {
      client.res.write(`event: ${type}\ndata: ${JSON.stringify(data)}\n\n`);
    } catch {
      sseClients.delete(client);
    }
  }
}

// Forward SMTP events to SSE
smtpEvents.on('new_email', (payload) => {
  broadcast('new_email', payload);
});

// Mailbox Authorization Middleware
function requireMailboxAuth(req, res, next) {
  const mailboxId = req.headers['x-mailbox-id'] || req.query.mailboxId;
  if (!mailboxId) {
    return res.status(401).json({ error: 'Mailbox authorization header (x-mailbox-id) required' });
  }

  const mailbox = getMailboxById(Number(mailboxId), false);
  if (!mailbox) {
    return res.status(403).json({ error: 'Invalid or unauthorized mailbox' });
  }

  req.authMailbox = mailbox;
  next();
}

// Stats API
app.get('/api/stats', (req, res) => {
  res.json({
    ...getStats(),
    smtpPort: SMTP_PORT,
    webPort: WEB_PORT,
    host: HOST
  });
});

// Domains API (Private DKIM keys filtered out)
app.get('/api/domains', (req, res) => {
  res.json(getDomains(false));
});

app.post('/api/domains', (req, res) => {
  const { name } = req.body;
  if (!name || !name.includes('.') || name.length < 3) {
    return res.status(400).json({ error: 'Valid fully qualified domain name required (e.g. brand.com)' });
  }
  try {
    const domain = createDomain(name);
    broadcast('domain_created', domain);
    res.json(domain);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

app.get('/api/domains/:id/dns', (req, res) => {
  const domain = getDomainById(Number(req.params.id), false);
  if (!domain) return res.status(404).json({ error: 'Domain not found' });

  // Generate complete DNS records bundle
  const dnsRecords = [
    {
      type: 'MX',
      name: '@',
      priority: 10,
      value: `mail.${domain.name}`,
      explanation: 'Directs incoming emails for your domain to this mail server.'
    },
    {
      type: 'TXT',
      name: '@',
      value: 'v=spf1 mx ~all',
      explanation: 'SPF Record: Declares that servers listed in MX are authorized to send mail.'
    },
    {
      type: 'TXT',
      name: `${domain.dkim_selector}._domainkey`,
      value: `v=DKIM1; k=rsa; p=${domain.dkim_public_key}`,
      explanation: 'DKIM Record: 2048-bit Public Key used by receiving servers to verify email signatures.'
    },
    {
      type: 'TXT',
      name: '_dmarc',
      value: `v=DMARC1; p=none; sp=none; rua=mailto:dmarc-reports@${domain.name}`,
      explanation: 'DMARC Record: Protects your domain from spoofing and receives delivery reports.'
    }
  ];

  res.json({ domain, dnsRecords });
});

// Mailboxes API (Password hashes filtered out)
app.get('/api/mailboxes', (req, res) => {
  const domainId = req.query.domainId ? Number(req.query.domainId) : null;
  res.json(getMailboxes(domainId, false));
});

app.post('/api/mailboxes', (req, res) => {
  const { domainId, email, name, password } = req.body;
  if (!domainId || !email || !name || !password) {
    return res.status(400).json({ error: 'domainId, email, name, and password are required' });
  }
  if (password.length < 8) {
    return res.status(400).json({ error: 'Password must be at least 8 characters long' });
  }
  try {
    const mailbox = createMailbox(Number(domainId), email, name, password);
    broadcast('mailbox_created', mailbox);
    res.json(mailbox);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// Emails API (Tenant-isolated with requireMailboxAuth)
app.get('/api/mailboxes/:id/emails', requireMailboxAuth, (req, res) => {
  const mailboxId = Number(req.params.id);
  if (req.authMailbox.id !== mailboxId) {
    return res.status(403).json({ error: 'Access denied to this mailbox' });
  }

  const folder = req.query.folder || 'inbox';
  const emails = getEmails(mailboxId, folder);
  res.json(emails);
});

app.get('/api/emails/:id', requireMailboxAuth, (req, res) => {
  const email = getEmailById(Number(req.params.id), req.authMailbox.id);
  if (!email) {
    return res.status(404).json({ error: 'Email not found or access denied' });
  }
  res.json(email);
});

app.post('/api/emails/send', requireMailboxAuth, async (req, res) => {
  const { fromEmail, toEmail, subject, bodyText, bodyHtml, attachments } = req.body;
  if (!fromEmail || !toEmail) {
    return res.status(400).json({ error: 'fromEmail and toEmail are required' });
  }

  // Ensure user can only send from their own authorized mailbox
  if (req.authMailbox.email.toLowerCase() !== fromEmail.trim().toLowerCase()) {
    return res.status(403).json({ error: `Cannot send on behalf of unauthorized email ${fromEmail}` });
  }

  try {
    const result = await sendEmail({
      fromEmail,
      toEmail,
      subject,
      bodyText,
      bodyHtml,
      attachments
    });
    res.json(result);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/emails/:id/mark-read', requireMailboxAuth, (req, res) => {
  const isRead = req.body.isRead !== undefined ? (req.body.isRead ? 1 : 0) : 1;
  const result = markEmailRead(Number(req.params.id), req.authMailbox.id, isRead);
  if (!result.success) {
    return res.status(404).json({ error: 'Email not found or access denied' });
  }
  res.json({ success: true, isRead });
});

app.post('/api/emails/:id/star', requireMailboxAuth, (req, res) => {
  const result = toggleStarEmail(Number(req.params.id), req.authMailbox.id);
  if (!result.success) {
    return res.status(404).json({ error: 'Email not found or access denied' });
  }
  res.json({ success: true });
});

app.delete('/api/emails/:id', requireMailboxAuth, (req, res) => {
  const result = deleteEmail(Number(req.params.id), req.authMailbox.id);
  if (result.error) {
    return res.status(404).json({ error: result.error });
  }
  res.json(result);
});

// Live SMTP Logs API
app.get('/api/smtp-logs', (req, res) => {
  const limit = req.query.limit ? Number(req.query.limit) : 50;
  res.json(getSmtpLogs(limit));
});

// Start Servers on Loopback
startSmtpReceiver(SMTP_PORT, HOST);

app.listen(WEB_PORT, HOST, () => {
  console.log(`🌐 [Webmail & SaaS Dashboard] Running securely on http://${HOST}:${WEB_PORT}`);
  console.log(`🛡️ [SMTP Receiver Server] Running on ${HOST}:${SMTP_PORT}`);
});
